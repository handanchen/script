# 数据库连接信息
retail_fms="172.17.210.36 3307 retail_fms password utf8"
retail_gms="172.17.210.36 3307 retail_gms password utf8"
retail_mdm="172.17.210.36 3307 retail_mdm password utf8"
retail_mps="172.17.210.36 3307 retail_mps password utf8"
retail_pms_replenish="172.17.210.36 3307 retail_pms_rep password utf8"
retail_pos="172.17.210.36 3307 retail_pos password utf8"


# 记录日志
function log()
{
    echo "$(date +'%F %T') [$@]"
}

# 生成随机字符串
function random_num()
{
    echo $1 $2 | awk 'BEGIN{
        srand()
    }{
        digit=$1 > 0 ? $1 : 1
        num=$2 > 0 ? $2 : 1
        for(i=0;i < num;i++){
            value=10 ^ digit * rand()
            printf("%0*d\n",digit,value)
        }
    }'
}

# 执行sql语句
function execute_sql()
{
    local sql="$1"
    if [ -z "$sql" ]; then
        sql=`cat`
    fi

    log "$sql" >> sql_$(date +'%Y%m%d').log

    echo "$sql" | mysql -h$db_host -P$db_port -u$db_user -p$db_passwd $db_name --default-character-set=$db_charset -s -N
}
