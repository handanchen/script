#!/bin/bash
#
# 自动生成主从表数据


DIR=`pwd`

source $DIR/common.sh


# 待模拟的表
# 数据库名 主表名 从表名 关联字段 主表关联字段(默认和关联字段相同)
TABLES="retail_pms_replenish bill_grade_plan bill_grade_plan_dtl bill_no
retail_pms_replenish meetorder_staff meetorder_staff_dtl meetorder_staff_id id
retail_pms_replenish bill_order_standard_heel_set
retail_mdm brand
retail_gms bill_asn bill_asn_dtl
retail_mps item_group item_group_change_price,item_group_dtl,item_group_strategy group_no"

# 数据库连接信息(用于生成insert.sh脚本)
db_con='
db_info=(${!db_name})
db_host=${db_info[0]}
db_port=${db_info[1]}
db_user=${db_info[2]}
db_passwd=${db_info[3]}
db_charset=${db_info[4]}
'


# 获取非空/时间字段名
function get_columns()
{
    local table_name="$1"
    local join_keys="$2"
    if [[ -n "$join_keys" ]]; then
        include_columns=`echo "$join_keys" | tr ',' '|'`"|create_time|update_time"
    else
        include_columns="create_time|update_time"
    fi

    echo "desc $table_name;" | execute_sql | awk '$1 ~ /'$include_columns'/ || $3 == "NO" {print $1,$2}'
}

# 生成insert.sh脚本
function insert()
{
    echo -e "#!/bin/bash\n\n" > $DIR/insert.sh
    echo -e "DIR=\`pwd\`\n" >> $DIR/insert.sh
    echo -e "source \$DIR/common.sh\n" >> $DIR/insert.sh

    echo "$TABLES" | while read db_name m_table s_tables join_keys m_keys; do
        db_info=(${!db_name})
        db_host=${db_info[0]}
        db_port=${db_info[1]}
        db_user=${db_info[2]}
        db_passwd=${db_info[3]}
        db_charset=${db_info[4]}

        echo "# $db_name.$m_table begin"

        # UUID
        uuid=$(cat /proc/sys/kernel/random/uuid)
        # 当前时间
        cur_time=$(date +'%F %T')

        # 生成insert语句
        columns=`get_columns $m_table $join_keys | awk '{printf("%s,",$1)}' | sed 's/,$//'`
        values=`echo "$columns" | sed "s/^/'$/;s/$/'/;s/,/','$/g"`

        eval "echo db_name=$db_name"

        get_columns $m_table $join_keys | while read column_name column_type; do
            size=`echo "$column_type" | sed 's/[^0-9]*//g'`
            if [[ "$column_type" =~ int ]]; then
                if [[ "$column_type" =~ tiny ]]; then
                    size=2
                elif [[ "$column_type" =~ small ]]; then
                    size=4
                else
                    size=8
                fi
                rand_int="1"$(random_num $size)

                eval "echo $column_name=$rand_int"
            elif [[ "$column_type" =~ decimal ]]; then
                eval "echo $column_name=12.3"
            elif [[ "$column_type" =~ char ]]; then
                rand_str=$(random_num $size)
                eval "echo $column_name=\\\"$rand_str\\\""
            elif [[ "$column_type" =~ date ]]; then
                eval "echo $column_name=\\\"$cur_time\\\""
            fi
        done
        echo "insert_sql=\"INSERT IGNORE INTO $m_table ( $columns ) VALUES ( $values );\""
        echo -e "$db_con"
        echo -e "echo \"\$insert_sql\" | execute_sql\n"

        # 从表
        echo "$s_tables" | tr ',' '\n' | while read s_table; do
            if [[ -n "$s_table" ]]; then
                columns=`get_columns $s_table $join_keys | awk '{printf("%s,",$1)}' | sed 's/,$//'`
                values=`echo "$columns" | sed "s/^/'$/;s/$/'/;s/,/','$/g"`

                get_columns $s_table $join_keys | while read column_name column_type; do
                    size=`echo "$column_type" | sed 's/[^0-9]*//g'`
                    if [[ -n "$join_keys" && -n `echo "$join_keys" | grep $column_name` ]]; then
                        continue
                    fi

                    if [[ "$column_type" =~ int ]]; then
                        if [[ "$column_type" =~ tiny ]]; then
                            size=2
                        elif [[ "$column_type" =~ small ]]; then
                            size=4
                        else
                            size=8
                        fi
                        rand_int="1"$(random_num $size)

                        eval "echo $column_name=$rand_int"
                    elif [[ "$column_type" = ~decimal ]]; then
                        eval "echo $column_name=12.3"
                    elif [[ "$column_type" =~ char ]]; then
                        rand_str=$(random_num $size)
                        eval "echo $column_name=\\\"$rand_str\\\""
                    elif [[ "$column_type" =~ date ]]; then
                        eval "echo $column_name=\\\"$cur_time\\\""
                    fi
                done

                if [[ -n "$m_keys" ]]; then
                    eval "echo $join_keys=\\\"\\\$\$m_keys\\\""
                fi

                echo "insert_sql=\"INSERT IGNORE INTO $s_table ( $columns ) VALUES ( $values );\""
                echo -e "$db_con"
                echo -e "echo \"\$insert_sql\" | execute_sql\n"
            fi
        done
        echo "# $db_name.$m_table end"
    done >> $DIR/insert.sh
}

function update()
{
    echo "$TABLES" | while read db_name m_table s_tables join_keys m_keys; do
        db_info=(${!db_name})
        db_host=${db_info[0]}
        db_port=${db_info[1]}
        db_user=${db_info[2]}
        db_passwd=${db_info[3]}
        db_charset=${db_info[4]}

        echo "-- $db_name.$m_table begin"

        # UUID
        uuid=$(cat /proc/sys/kernel/random/uuid)
        # 当前时间
        cur_time=$(date +'%F %T')

        # 生成update语句
        echo "SET @id=;"
        echo "SET @update_time=NOW();"
        [[ -n "$join_keys" ]] && echo "$join_keys" | sed 's/^/SET @/;s/,/=;SET @/;s/$/=;/'
        echo "UPDATE $m_table SET update_time = @update_time WHERE id = @id;"
        # 从表
        echo "$s_tables" | tr ',' '\n' | while read s_table; do
            if [[ -n "$s_table" ]]; then
                [[ -n "$join_keys" ]] && join_columns="AND "`echo "$join_keys" | sed "s/\(.*\),/ \1 = @\1 AND /;s/\([^ ]*\)$/ \1 = @\1/"`
                echo "UPDATE $s_table SET update_time = @update_time WHERE id = @id $join_columns;"
            fi
        done

        echo -e "-- $db_name.$m_table end\n"
    done > $DIR/update.sql
}

function main()
{
    # 删除旧数据
    rm -f $DIR/sql_*.log $DIR/insert.sh $DIR/update.sql

    log "generate insert script begin"
    insert
    log "generate insert script end"

    # 执行insert
    log "execute insert script begin"
    sh $DIR/insert.sh
    log "execute insert script end"
}
main "$@"
