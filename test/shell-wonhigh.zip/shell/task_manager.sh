#!/bin/bash
#
# 任务管理器
# 作用:
#   获取待运行任务
#   控制任务并发数
#   启动任务


DIR=`pwd`

source $DIR/config.sh
source $DIR/common.sh
source $DIR/task_config.sh
source $DIR/task_common.sh

# 待同步任务所在库
DBS="'retail_gms','retail_pos','retail_mdm','retail_mps','retail_pms_replenish','retail_fms'"

#创建目录
mkdir -p $TASK_LOG_PATH 2> /dev/null
mkdir -p $SQL_LOG_PATH 2> /dev/null

# 获取任务
# Globals:
# Arguments:
# Returns:
function get_tasks()
{
    execute_meta "SELECT id FROM t_task_config WHERE config_status = 1 AND sync_status = 0 AND schema_name IN ($DBS) LIMIT $TASK_FETCH_SIZE"
}

# 启动任务
# Globals:
# Arguments:
# Returns:
function execute()
{
    get_tasks | while read task_id; do
        # 检查当前任务并发数
        if [ `ps -ef | grep "task_runner\.sh" | wc -l` -le $MAX_THREAD_COUNT ]; then
            nohup sh task_runner.sh $task_id > $TASK_LOG_PATH/${task_id}.log 2> $TASK_LOG_PATH/${task_id}.err &
        else
            break
        fi
    done
}

function main()
{
    # 是否执行一次后退出，非空时循环扫描
    daemon="$1"

    while [ -n "$daemon" ]; do
        execute
        sleep $TASK_CHECK_INTERVAL
    done || exit $?
    execute
}
main "$@"
