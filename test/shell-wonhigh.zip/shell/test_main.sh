#!/bin/bash
#
# tpch测试


# 数据文件目录
DATA_DIR=/data/wonhigh/data_scale
# 报告目录
REPORT_DIR=/data/wonhigh/report/postgres
# 任务配置文件路径
TASK_DIR=/data/wonhigh/script

# 创建目录
mkdir -p $DATA_DIR 2> /dev/null
mkdir -p $REPORT_DIR 2> /dev/null
mkdir -p $TASK_DIR 2> /dev/null

# 测试表
TEST_TABLES="lineitem,orders,partsupp,part,customer,supplier,nation,region"

# 测试数据规模
TEST_SCALES="1,10,30,100,300,1000"

# 测试次数
TEST_TIMES=1


# 记录日志
function log()
{
    echo -e "$(date +'%Y-%m-%d %H:%M:%S')\t$@"
}

# 执行plsql命令
# Globals:
# Arguments:
# Returns:
function psql_executor()
{
    local sql="$1"
    if [ -z "$sql" ]; then
        sql=`cat`
    fi

    echo "$sql" | psql -h172.17.209.102 -Utpch -dtpch
}

# 删除表
# Globals:
# Arguments:
# Returns:
function drop_table()
{
    echo "$TEST_TABLES" | awk 'BEGIN{RS=","}{
        print "drop table "$1" CASCADE;"
    }' | psql_executor
}

# 创建表
# Globals:
# Arguments:
# Returns:
function create_table()
{
    psql -h172.17.209.102 -Utpch -dtpch -f ${TASK_DIR}/dss-pg.ddl
}

# 添加约束
# Globals:
# Arguments:
# Returns:
function add_constraint()
{
    psql -h172.17.209.102 -Utpch -dtpch -f ${TASK_DIR}/dss-pg.ri
}

# 获取数据
# Globals:
# Arguments:
# Returns:
function get_data()
{
    ./expect_scp 172.17.209.111 root belle $DATA_DIR/${the_scale}/ $DATA_DIR/
}

# 装载数据
# Globals:
# Arguments:
# Returns:
function load_data()
{
    echo "$TEST_TABLES" | awk 'BEGIN{RS=","}{print $1}' | while read table_name; do
        # 装载数据
        (time psql -h172.17.209.102 -Utpch -c "COPY $table_name   FROM stdin WITH (FORMAT csv, DELIMITER '|')" < ${DATA_DIR}/${the_scale}/${table_name}.tbl) > ${REPORT_DIR}/${the_scale}/${table_name}.load 2>&1

        # 统计装载时间
        grep "real" ${REPORT_DIR}/${the_scale}/${table_name}.load | sed "s/real[[:space:]]*\(.*\)/${table_name}\t\1/ig" >> ${REPORT_DIR}/${the_scale}/load.log
    done
}

# 执行单个task
# Globals:
# Arguments:
# Returns:
function execute_single()
{
    jmeter -n -t ${TASK_DIR}/postgresql-single-plan-${the_scale}.jmx -l ${REPORT_DIR}/${the_scale}/postgres_single.log
}

# 执行多个任务
# Globals:
# Arguments:
# Returns:
function execute_multi()
{
    local the_plan="$1"

    jmeter -n -t ${TASK_DIR}/postgresql-multi-${the_plan}-plan-${the_scale}.jmx -l ${REPORT_DIR}/${the_scale}/postgres_multi.log
}

# 清除数据
# Globals:
# Arguments:
# Returns:
function clear_data()
{
    rm -rf ${DATA_DIR}/${the_scale}/
}

# 清理结果
# Globals:
# Arguments:
# Returns:
function clear_result()
{
    rm -f ${REPORT_DIR}/${the_scale}/load.log 2> /dev/null
    rm -f ${REPORT_DIR}/${the_scale}/query.log 2> /dev/null
    rm -f ${REPORT_DIR}/${the_scale}/report_jh.csv 2> /dev/null
    rm -f ${REPORT_DIR}/${the_scale}/datetime.log 2> /dev/null
}

# 统计查询时间
# Globals:
# Arguments:
# Returns:
function statistic()
{
    awk -F ',' 'BEGIN{OFS="\t"}{
        sub("-.*","",$3)
        sum[$3]+=$2
    }END{
        for(key in sum){
            print key,sum[key]
        }
    }' $REPORT_DIR/${the_scale}/report_jh.csv |
    sort -n  >> $REPORT_DIR/${the_scale}/query.log
}

# 执行操作
# Globals:
# Arguments:
# Returns:
function execute()
{
    mkdir -p ${REPORT_DIR}/${the_scale} 2> /dev/null

    seq $TEST_TIMES | while read the_time; do
        # 删除表
        drop_table
        # 创建表
        create_table
        # 获取数据
        get_data

        # 开始时间
        log "load data begin" >> $REPORT_DIR/${the_scale}/datetime.log
        # 导入数据
        load_data
        # 结束时间
        log "load data end" >> $REPORT_DIR/${the_scale}/datetime.log

        # 添加约束
        add_constraint

        # 开始时间
        log "single query begin" >> $REPORT_DIR/${the_scale}/datetime.log
        execute_single
        # 结束时间
        log "single query end" >> $REPORT_DIR/${the_scale}/datetime.log

        # 开始时间
        log "multi query a begin" >> $REPORT_DIR/${the_scale}/datetime.log
        execute_multi a
        # 结束时间
        log "multi query a end" >> $REPORT_DIR/${the_scale}/datetime.log
        
        # 开始时间
        log "multi query b begin" >> $REPORT_DIR/${the_scale}/datetime.log
        execute_multi b
        # 结束时间
        log "multi query b end" >> $REPORT_DIR/${the_scale}/datetime.log

        # 统计数据
        statistic
        # 清除数据
        clear_data
    done
}

function main()
{
    clear_result

    echo "$TEST_SCALES" | awk 'BEGIN{RS=","}{print $1}' | while read the_scale; do
        execute
    done
}
main "$@"
