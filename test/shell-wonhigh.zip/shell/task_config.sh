#!/bin/bash
#
# 任务配置信息


# 元数据库
META_DB_HOST=172.17.210.180
META_DB_PORT=3306
META_DB_USER=dc_scheduler_cli
META_DB_PASS=dc_scheduler_cli
META_DB_NAME=dc_scheduler_client
META_DB_CHARSET=utf8
META_DB_PARAMS="-s -N"

# 任务日志目录
TASK_LOG_PATH=${LOG_PATH}/task

# 任务状态
TASK_STATUS_INIT=0
TASK_STATUS_RUNNING=1
TASK_STATUS_PAUSED=2
TASK_STATUS_SUCCESS=6
TASK_STATUS_FAILED=9

# 一次获取任务数量
TASK_FETCH_SIZE=10

# 最大并发数
MAX_THREAD_COUNT=5

# 任务扫描时间间隔
TASK_CHECK_INTERVAL=10

# 页大小
PAGE_SIZE=100000

# 源库和目标库的对应关系
retail_gms="172.17.210.180 3306 retail_gms retail_gms utf8 dc_retail_gms"
retail_pos="172.17.210.180 3306 retail_pos retail_pos utf8 dc_retail_pos"
retail_mdm="172.17.210.180 3306 retail_mdm retail_mdm utf8 dc_retail_mdm"
retail_mps="172.17.210.134 8066 retail_mps retail_mps utf8 dc_retail_mps"
retail_fms="172.17.210.180 3306 retail_fms retail_fms utf8 dc_retail_fas"
retail_pms_replenish="172.17.210.180 3306 pms_replenish retail_pms_replenish utf8 dc_retail_pms"
