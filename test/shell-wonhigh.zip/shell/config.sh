#!/bin/bash
#
# 基本配置信息


# sql日志开关
SQL_LOG=on

# 日志目录
LOG_PATH=~/log
# sql日志目录
SQL_LOG_PATH=${LOG_PATH}/sql
# 临时文件目录
TMP_PATH=~/tmp
# 数据文件目录
DATA_PATH=~/data

# 指令
CMD_CREATE_TABLE=table          # 创建表
CMD_CREATE_EXP=table_file       # 创建表、导出文件
CMD_CREATE_IMP=table_file_data  # 创建表、导入数据
CMD_EXP_FILE=file               # 导出文件
CMD_IMP_DATA=file_data          # 导入数据
