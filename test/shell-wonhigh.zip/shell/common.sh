#!/bin/bash
#
# 常用工具

# 记录日志
function log()
{
    echo "[$(date +'%Y-%m-%d %H:%M:%S')]: $@"
}

# 记录日志到错误输出
function err()
{
    log "$@" >&2
}

# 在方法执行前后记录日志
function log_fn()
{
    echo "[$(date +'%Y-%m-%d %H:%M:%S')]: $@ begin"
    $@ || return $?
    echo "[$(date +'%Y-%m-%d %H:%M:%S')]: $@ end"
}

#hive转义特殊字符
function hive_escape()
{
    sed "s/\('\|;\)/\\\\\1/g"
}
