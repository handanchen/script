#!/bin/bash
#
# 任务运行器
# 作用:
#   执行任务
#   更新任务状态

DIR=`pwd`

source $DIR/config.sh
source $DIR/common.sh
source $DIR/task_config.sh
source $DIR/task_common.sh
source $DIR/mysql2hive.sh


# 获取任务配置信息
# Globals:
# Arguments:
# Returns:
function get_task_info()
{
    execute_meta "SELECT group_name,trigger_name,schema_name,table_name,
        IF(TRIM(sync_col_name)>'',TRIM(sync_col_name),NULL) sync_col_name,
        IF(TRIM(incr_columns)>'',TRIM(incr_columns),NULL) incr_columns,
        IFNULL(UNIX_TIMESTAMP(sync_begin_time),0) sync_begin_time,
        UNIX_TIMESTAMP() sync_end_time 
        FROM t_task_config 
        WHERE id = $task_id
    "
}

# 更新任务状态
# Globals:
# Arguments:
# Returns:
function update_task_status()
{
    local task_status="$1"

    if [ $task_status -ne $TASK_STATUS_SUCCESS ]; then
        local sql="update t_task_config set sync_status=$task_status where id=$task_id"
    else
        local sql="update t_task_config set sync_status=$task_status,sync_begin_time=FROM_UNIXTIME($end_time) where id=$task_id"
    fi

    execute_meta "$sql"
}

# 执行任务
# Globals:
# Arguments:
# Returns:
function execute()
{
    #更新任务状态为1（正在运行）
    update_task_status $TASK_STATUS_RUNNING

    #开始同步
    transfer

    if [ $? -eq 0 ]; then
        #更新任务状态为6（成功）
        update_task_status $TASK_STATUS_SUCCESS
    else
        #更新任务状态为9（失败）
        update_task_status $TASK_STATUS_FAILED
    fi
}

function main()
{
    task_id="$1"

    #读取任务配置信息
    task_info=($(get_task_info))

    #设置任务参数
    schema_name=${task_info[2]}
    table_name=${task_info[3]}
    incr_columns=${task_info[5]}
    begin_time=${task_info[6]}
    end_time=${task_info[7]}

    if [[ -n "$incr_columns" && "$incr_columns" != "NULL" ]]; then
        create_time=${incr_columns%,*}
        update_time=${incr_columns#*,}
        if [[ "$create_time" = "$update_time" ]]; then
            where=" AND ( $create_time >= FROM_UNIXTIME($begin_time) AND $create_time < FROM_UNIXTIME($end_time) ) "
        else
            where=" AND ( ( $create_time >= FROM_UNIXTIME($begin_time) AND $create_time < FROM_UNIXTIME($end_time) ) OR ( $update_time >= FROM_UNIXTIME($begin_time) AND $update_time < FROM_UNIXTIME($end_time) ) )"
        fi
    fi

    #设置数据源
    local db_info=(${!schema_name})
    set_src_db ${db_info[0]} ${db_info[1]} ${db_info[2]} ${db_info[3]} ${schema_name} ${db_info[4]} "-s -N"

    #设置数据目标
    set_tar_db ${db_info[5]}

    #设置要执行的操作
    action=$CMD_CREATE_TABLE

    execute
}
main "$@"
