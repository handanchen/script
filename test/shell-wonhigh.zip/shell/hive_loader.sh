#!/bin/bash

#������Ϣ
function init_config()
{
    #�����ļ�Ŀ¼
    data_path=~/data
    #�����ļ�����Ŀ¼
    data_backup_path=~/data/backup

    hive_db="default"

    mkdir -p $data_path 2> /dev/null
    mkdir -p $data_backup_path 2> /dev/null
}

#װ�ص�hive
function load_hive()
{
    ls $data_path/*.zip | while read file_name;do
        unzip -u $file_name -d `dirname $file_name`
        hive -S --database $hive_db -f ${file_name%.*}.ctl &&
        hive -S --database $hive_db -e "load data local inpath '${file_name%.*}.txt' into table `basename ${file_name%.*}`;" &&
        mv $file_name $data_backup_path
    done
}

function main()
{
    init_config

    load_hive
}
main
