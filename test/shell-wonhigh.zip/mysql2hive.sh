#!/bin/bash
#
# mysql到hive表结构复制


# 元数据库配置信息
META_DB_HOST=172.17.210.180
META_DB_PORT=3306
META_DB_USER=dc_scheduler_cli
META_DB_PASSWD=dc_scheduler_cli
META_DB_NAME=dc_scheduler_client
META_DB_CHARSET=utf8
META_DB_PARAMS="-s -N"

# 源库名和目标库名的对应关系
retail_gms=dc_retail_gms
retail_pos=dc_retail_pos
retail_mdm=dc_retail_mdm
retail_mps=dc_retail_mps
retail_fms=dc_retail_fms
retail_pms_replenish=dc_retail_pms

# 临时文件目录
TMP_PATH=~/tmp


# 执行元数据库sql语句
function execute_meta()
{
    local sql="$1"
    if [ -z "$sql" ]; then
        sql=`cat`
    fi

    echo "$sql" | mysql -h$META_DB_HOST -P$META_DB_PORT -u$META_DB_USER -p$META_DB_PASSWD $META_DB_NAME --default-character-set=$META_DB_CHARSET $META_DB_PARAMS
}

# 获取任务列表
function get_task_list()
{
    echo "SELECT 
    c.hostname,
    c.port,
    c.username,
    c.password,
    c.db_name,
    c.charset,
    a.table_name 
    FROM meta_tables a 
    INNER JOIN meta_tasks b 
    INNER JOIN meta_dbs c 
    ON a.id = b.id 
    AND b.valid = 1 
    AND a.db_id = c.id;
    " | execute_meta
}

# 设置数据源
function set_src_db()
{
    src_db_host="$1"
    src_db_user="$2"
    src_db_passwd="$3"
    src_db_name="$4"
    src_db_port="$5"
    src_db_charset="$6"
    src_db_params="${7:--s -N}"
}

# 执行数据源sql语句
function mysql_executor()
{
    local sql="$1"
    if [ -z "$sql" ]; then
        sql=`cat`
    fi

    echo "$sql" | mysql -h$src_db_host -P$src_db_port -u$src_db_user -p$src_db_passwd $src_db_name --default-character-set=$src_db_charset $src_db_params
}

# 整型类型转换
function conv_int()
{
    sed 's/ [^ ]*int(.*)$/ int/ig;s/ year[^ ]*$/ int/ig'
}

# 字符类型转换
function conv_string()
{
    sed 's/ \(text\| enum(.*)\| set(.*)\| blob\)$/ string/ig'
}

# 日期类型转换
function conv_date()
{
    sed 's/ datetime.*/ timestamp/ig;s/ date&\| date(.*)$/ date/ig;s/ time$/ string/ig'
}

# 数据类型转换
function conv_data_type()
{
    conv_int | conv_string | conv_date
}

# hive转义特殊字符
# (' ;)
function hive_escape()
{
    sed "s/\('\|;\)/\\\\\1/g"
}

# 记录日志
function log()
{
    echo "$(date +'%F %T') [$@]"
}

# 获取表注释
function get_table_comment()
{
    grep "ENGINE=.* COMMENT=" $TMP_PATH/$src_db_name/$table_name.def | sed "s/.* COMMENT=\(.*\)/\1/i;s/'//g"
}

# 获取字段
function get_columns()
{
    sed '1d;$d' $TMP_PATH/$src_db_name/$table_name.def | grep -Eiv " KEY " | sed 's/\([ ]*[^ ]*[ ]*[^ ]*\).*/\1/ig;s/`//g' | conv_data_type
}

# 获取字段注释
function get_columns_comment()
{
    sed '1d;$d' $TMP_PATH/$src_db_name/$table_name.def |
    grep -Eiv " KEY " |
    sed "s/.*COMMENT '\(.*\)',$/\1/ig;s/^[[:space:]]*\`.*//g" |
    sed 's/\\/\\\\/g' |
    hive_escape |
    sed "s/\(.*\)/COMMENT '\1',/g"
}

# 生成建表语句
function build_create_sql()
{
    echo "CREATE TABLE IF NOT EXISTS ${table_name} ("
    paste $TMP_PATH/$src_db_name/$table_name.cols $TMP_PATH/$src_db_name/$table_name.cmts #| sed '$s/,$//'
    echo "  hive_create_time timestamp"
    echo ") COMMENT '`get_table_comment`' PARTITIONED BY (biz_date int) ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t' STORED AS TEXTFILE;"
}

# 创建表
function create_table()
{
    # 创建目录
    mkdir -p $TMP_PATH/$src_db_name

    # 获取表定义
    log "get table defination begin"
    mysql_executor "SHOW CREATE TABLE $table_name\G;" | sed -n '3,$p' > $TMP_PATH/$src_db_name/$table_name.def
    log "get table defination end"

    # 获取字段
    log "get columns begin"
    get_columns > $TMP_PATH/$src_db_name/$table_name.cols
    log "get columns end"

    # 获取字段注释
    log "get columns comment begin"
    get_columns_comment > $TMP_PATH/$src_db_name/$table_name.cmts
    log "get columns comment end"

    # 生成hive建表语句
    log "build create sql begin"
    build_create_sql > $TMP_PATH/$src_db_name/$table_name.ctl
    log "build create sql end"
}

# 特殊表处理
function special_tables()
{
    # 包含特殊表的源库名
    local special_dbs=(retail_mps retail_pms_replenish)

    # 特殊表对应id
    local retail_mps="105,106,107,116,117,119,120,121,123,124,129,130,132"
    local retail_pms_replenish="239,246,245,248,252,255,257,265,267,271"

    # 查找特殊表，并在对应文件插入字段(create_time和update_time)
    for db_name in "${special_dbs[@]}"; do
        table_ids=`echo ${!db_name} | tr ',' '|'`
        awk -F '\t' '{
            if($1 ~ /'$table_ids'/) print db_name,$4
        }' db_name=$db_name table_ids=$table_ids $TMP_PATH/${db_name}.tmp
    done | while read db_name table_name; do
        flag=`grep -E " create_time | update_time " $TMP_PATH/$db_name/$table_name.ctl`
        if [[ -z "$flag" ]]; then
            sed -i '/hive_create_time/i\  create_time timestamp,' $TMP_PATH/$db_name/$table_name.ctl
            sed -i '/hive_create_time/i\  update_time timestamp,' $TMP_PATH/$db_name/$table_name.ctl
        fi
    done

    # 合并数据库脚本
    local dbs=(retail_gms retail_pos retail_mdm retail_mps retail_fms retail_pms_replenish)
    for db_name in "${dbs[@]}"; do
        echo "use ${!db_name};" | cat - $TMP_PATH/$db_name/*.ctl > $TMP_PATH/$db_name.ctl
    done
}

function main()
{
    get_task_list | while read hostname port username password db_name charset table_name; do
        # 设置数据源
        set_src_db $hostname $username $password $db_name $port $charset

        # 创建表
        log "create table $db_name.$table_name begin"
        create_table
        log "create table $db_name.$table_name end"
    done

    # 特殊表处理
    special_tables
}
main "$@"
